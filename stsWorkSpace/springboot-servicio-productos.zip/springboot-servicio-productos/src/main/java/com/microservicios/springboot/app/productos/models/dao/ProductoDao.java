// 9. Creando el repositorio JPA para los productos
package com.microservicios.springboot.app.productos.models.dao;

import org.springframework.data.repository.CrudRepository;
import com.microservicios.springboot.app.productos.models.entity.Producto;

public interface ProductoDao extends CrudRepository<Producto, Long>{
	
}
