package com.microservicios.springboot.app.productos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
